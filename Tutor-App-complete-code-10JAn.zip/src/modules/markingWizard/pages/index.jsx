import React from "react";

function MarkingWizard() {
  return <div>MarkingWizard</div>;
}

export default MarkingWizard;
