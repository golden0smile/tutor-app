// Contact
export const FirstNameRequired = "Please enter first name.";

//common table
export const noDataFoundMsg = "No Data found";

//add activity module
export const noActivityMsg = "No activities selected yet";
