readme file for tutor
